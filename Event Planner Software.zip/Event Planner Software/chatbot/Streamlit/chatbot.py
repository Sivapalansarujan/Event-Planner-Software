import os
from dotenv import load_dotenv
from flask import Flask, request, jsonify, session
from flask_cors import CORS
from PyPDF2 import PdfReader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_community.llms import OpenAI
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory

# Load environment variables from .env file
load_dotenv()

# Flask app initialization
app = Flask(__name__)
CORS(app)
app.secret_key = os.urandom(24)  # Secret key for session

# Initialize session variables
app.config['CHAT_HISTORY'] = []
app.config['USER_CHAT_HISTORY'] = []
app.config['MEMORY'] = ConversationBufferMemory(memory_key="chat_history", return_messages=True, output_key="answer")
app.config['MEMORY02'] = ConversationBufferMemory(memory_key="chat_history", return_messages=True, output_key="answer")
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['PDF'] = None

def chunk_text(pdf_file):
    text = ""
    with open(pdf_file, 'rb') as file:
        pdf_reader = PdfReader(file)
        for page in pdf_reader.pages:
            text += page.extract_text()

    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
        length_function=len
    )
    chunks = text_splitter.split_text(text=text)
    return chunks

def handle_embedding(chunks):
    embeddings = OpenAIEmbeddings()
    vectorstore = FAISS.from_texts(chunks, embedding=embeddings)
    return vectorstore

def handle_conversation(vectorstore, memory):
    llm = OpenAI(temperature=0, model_name='gpt-3.5-turbo')
    qa = ConversationalRetrievalChain.from_llm(
        llm=llm,
        memory=memory,
        retriever=vectorstore.as_retriever()
    )
    return qa

@app.route("/api/get_pdf", methods=["POST", "GET"]) #Pdf file upload for service provider
def get_pdf():
    try:
        if 'file' not in request.files:
            print("No file part")
            return jsonify({"error": "No file part"}), 400

        file = request.files['file']
        if file.filename == '':
            print("No selected file")
            return jsonify({"error": "No selected file"}), 400

        if file and file.filename.endswith('.pdf'):
            filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(filename)
            app.config['PDF'] = filename
            print("File uploaded successfully")
            return jsonify({"message": "File uploaded successfully"}), 200
        else:
            print("Please upload a PDF file")
            return jsonify({"error": "Please upload a PDF file"}), 400
    except Exception as e:
        print("Error:", e)
        return jsonify({"error": str(e)}), 500

@app.route("/api/process_query", methods=["POST", "GET"]) # Query process for service provider
def process_query():
    try:
        if app.config['PDF'] is None:
            print("No file uploaded")
            return jsonify({"error": "No file uploaded"}), 400

        pdf_file = app.config['PDF']
        if not os.path.exists(pdf_file):
            print("PDF file not found")
            return jsonify({"error": "PDF file not found"}), 400

        chunks = chunk_text(pdf_file)
        vectorstore = handle_embedding(chunks)
        memory = app.config['MEMORY']
        qa = handle_conversation(vectorstore, memory)
        query = request.json.get("query")

        if query:
            response = qa({'question': query})
            app.config['CHAT_HISTORY'].append(("User: " + query))
            app.config['CHAT_HISTORY'].append(("Bot: " + response['answer']))
            return jsonify({"response": response['answer'], "chat_history": app.config['CHAT_HISTORY']})
        else:
            print("No query provided")
            return jsonify({"error": "No query provided"}), 400

    except Exception as e:
        print("Error:", e)
        return jsonify({"error": str(e)}), 500
    
@app.route("/api/main", methods=["POST", "GET"]) #Query process for user
def main():
    load_dotenv()
    pdf = "./Event.pdf"  # Path to PDF file
    try:
        if request.method == "POST":
            # Handle POST request
            if pdf is not None:
                chunks = chunk_text(pdf)
                vectorstore = handle_embedding(chunks)
                memory = app.config['MEMORY02']
                qa = handle_conversation(vectorstore, memory)
                query = request.json.get("query")

                if query:
                    response02 = qa({'question': query})
                    app.config['USER_CHAT_HISTORY'].append(("User: " + query))
                    app.config['USER_CHAT_HISTORY'].append(("Bot: " + response02['answer']))
                    return jsonify({"response": response02['answer'], "chat_history02": app.config['USER_CHAT_HISTORY']})
                else:
                    return jsonify({"error": "No query provided"}), 400
        elif request.method == "GET":
            # Handle GET request
            return jsonify({"message": "This is the GET method for /api/main"})
    except Exception as e:
        print("Error:", e)
        return jsonify({"error": str(e)}), 500

@app.route("/api/chat_history", methods=["GET"]) #chat history for service provider
def get_chat_history():
    return jsonify({"chat_history": app.config['CHAT_HISTORY']})

@app.route("/api/user_chat_history", methods=["GET"]) #Chat history for user
def get_user_chat_history():
    return jsonify({"chat_history02": app.config['USER_CHAT_HISTORY']})

@app.route("/")
def index():
    return "Welcome to the Chatbot"

if __name__ == '__main__':
    app.run(debug=True, port=5013)