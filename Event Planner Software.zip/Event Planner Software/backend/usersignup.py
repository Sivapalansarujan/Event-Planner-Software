from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_mysqldb import MySQL

app = Flask(__name__)
CORS(app)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'MySQL@12345'
app.config['MYSQL_DB'] = 'eventplannerdb'

mysql = MySQL(app)

@app.route('/user_signup', methods=['POST'])
def user_signup():
    try:
        data = request.json
        name = data.get('name')
        email = data.get('email')
        password = data.get('password')
        contact = data.get('contact')
        
        # Check if required fields are missing
        if not name or not email or not password or not contact:
            return jsonify({'error': 'Missing required fields'}), 400

        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO user (UserName, Email, Password, ContactNumber) VALUES (%s, %s, %s, %s)", (name, email, password, contact))
        mysql.connection.commit()
        cursor.close()

        return jsonify({'message': 'User signed up successfully'}), 201

    except Exception as e:
        print('Error signing up user:', e)  # Print error message to console for debugging
        return jsonify({'error': 'An error occurred while signing up user'}), 500

if __name__ == '__main__':
    app.run(debug=True)
