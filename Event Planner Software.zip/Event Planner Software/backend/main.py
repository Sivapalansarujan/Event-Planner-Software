from threading import Thread
from flask import Flask
from login import app as app_login
from usersignup import app as app_usersignup
from serviceprovidersignup import app as app_serviceprovidersignup
from userprofile import app as app_userprofile
from serviceproviderprofileforuser import app as app_serviceproviderprofileforuser
from serviceproviderprofileforserviceproviderprofile import app as app_serviceproviderprofileforserviceproviderprofile
from ratingserviceprovider import app as app_ratingserviceprovider
from ratinguser import app as app_ratinguser
from eventplanningtool import app as app_eventplanningtool
from analytics import app as app_analytics
from resetpassword import app as app_resetpassword


def run_app(app, port):
    app.run(debug=True, port=port, use_reloader=False)  # Disable the reloader

if __name__ == '__main__':
    # Define ports for each app
    ports = {
        'login': 5000,
        'usersignup': 5001,
        'userprofile': 5002,
        'serviceproviderprofileforserviceproviderprofile': 5003,
        'serviceproviderprofileforuser': 5007,
        'ratingserviceprovider': 5004,
        'ratinguser': 5005,
        'serviceprovidersignup' : 5006,
        'eventplanningtool' : 5008,
        'analytics' : 5009,
        'resetpassword' : 5010
    }

    # Create and start a thread for each app
    threads = []
    for app_name, app_instance in [
        ('login', app_login),
        ('usersignup', app_usersignup),
        ('userprofile', app_userprofile),
        ('serviceproviderprofileforserviceproviderprofile', app_serviceproviderprofileforserviceproviderprofile),
        ('serviceproviderprofileforuser', app_serviceproviderprofileforuser),
        ('ratingserviceprovider', app_ratingserviceprovider),
        ('ratinguser' , app_ratinguser),
        ('serviceprovidersignup' , app_serviceprovidersignup),
        ('eventplanningtool' , app_eventplanningtool),
        ('analytics', app_analytics),
        ('resetpassword',app_resetpassword)
    ]:
        thread = Thread(target=run_app, args=(app_instance, ports[app_name]))
        threads.append(thread)
        thread.start()

    # Wait for all threads to complete
    for thread in threads:
        thread.join()
