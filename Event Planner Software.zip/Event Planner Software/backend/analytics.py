from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_mysqldb import MySQL

app = Flask(__name__)
CORS(app)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'MySQL@12345'
app.config['MYSQL_DB'] = 'eventplannerdb'

mysql = MySQL(app)

@app.route('/analytics', methods=['GET'])
def get_analytics():
    try:
        # Get logged-in service provider's email from request
        email = request.args.get('email')

        # Fetch service category for the logged-in service provider
        cursor = mysql.connection.cursor()
        cursor.execute('''SELECT CategoryID FROM service_provider WHERE Email = %s''', (email,))
        category_id = cursor.fetchone()[0]
        
        # Fetch service providers in the same category
        cursor.execute('''SELECT ServiceProviderID FROM service_provider WHERE CategoryID = %s''', (category_id,))
        service_provider_ids = [row[0] for row in cursor.fetchall()]
        
        # Calculate average rating for each service provider
        ratings = {}
        for provider_id in service_provider_ids:
            cursor.execute('''SELECT AVG(RatingValue) FROM rating WHERE ServiceProviderID = %s''', (provider_id,))
            avg_rating = cursor.fetchone()[0]
            ratings[provider_id] = avg_rating
        
        # Count number of events for each service provider
        events = {}
        for provider_id in service_provider_ids:
            cursor.execute('''SELECT COUNT(*) FROM confirmed_event WHERE ServiceProviderID_FK = %s''', (provider_id,))
            event_count = cursor.fetchone()[0]
            events[provider_id] = event_count

        cursor.close()

        # Prepare response data
        analytics_data = {
            "ratings": ratings,
            "events": events
        }

        return jsonify({"success": True, "analytics_data": analytics_data})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})


if __name__ == '__main__':
    app.run(debug=True)
