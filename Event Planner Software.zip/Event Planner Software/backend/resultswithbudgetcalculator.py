from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_mysqldb import MySQL
from flask import request

app = Flask(__name__)
CORS(app)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'MySQL@12345'
app.config['MYSQL_DB'] = 'eventplannerdb'

mysql = MySQL(app)

@app.route('/bestServiceproviders', methods=['POST'])
def find_best_serviceprovider():
    try:
        # Retrieve selected services from request body
        request_data = request.json
        selectedServices = request_data.get('selectedServices')

        # Log the selected services for debugging
        print("Selected Services:", selectedServices)

        # Dictionary to store the best service providers for each service
        best_service_providers = {}

        # Iterate over selected services to find the best service provider for each
        for service in selectedServices:
            cursor = mysql.connection.cursor()
            cursor.execute("SELECT sp.ServiceProviderID, AVG(r.RatingValue) AS AvgRating FROM service_provider sp INNER JOIN rating r ON sp.ServiceProviderID = r.ServiceProviderID WHERE sp.AvailableService = %s GROUP BY sp.ServiceProviderID", (service,))
            result = cursor.fetchall()
            cursor.close()
            
            # Find the service provider with the highest average rating
            if result:
                best_service_provider = max(result, key=lambda x: x[1])
                best_service_providers[service] = best_service_provider

        # If no service providers are found, return an empty response
        if not best_service_providers:
            return jsonify({'message': 'No service providers found for the selected services'}), 404

        # Dictionary to store service provider amounts
        service_provider_amounts = {}

        # Retrieve amount for each selected service provider
        for service, provider_info in best_service_providers.items():
            cursor = mysql.connection.cursor()
            cursor.execute("SELECT Amount FROM service_provider WHERE ServiceProviderID = %s", (provider_info[0],))
            amount = cursor.fetchone()[0]
            cursor.close()
            service_provider_amounts[service] = amount

        # Calculate total amount
        total_amount = sum(service_provider_amounts.values())

        # Send the best service providers and their corresponding amounts to the frontend
        return jsonify({
            'message': 'Best service providers found successfully', 
            'bestServiceProviders': best_service_providers,
            'serviceProviderAmounts': service_provider_amounts,
            'totalAmount': total_amount
        }), 200

    except Exception as e:
        print('Error finding best service providers:', e)  # Add error logging
        return jsonify({'error': str(e)}), 500

# Endpoint to confirm booking
@app.route('/confirmBooking', methods=['POST'])
def confirm_booking():
    try:
        # Retrieve eventID and selectedServiceProviders from request body
        request_data = request.json
        eventID = request_data.get('eventID')
        selectedServiceProviders = request_data.get('selectedServiceProviders')

        # Store the selected service providers in the database (confirmed_event table)
        cursor = mysql.connection.cursor()
        for serviceProviderID in selectedServiceProviders:
            cursor.execute("INSERT INTO confirmed_event (EventID_FK, ServiceProviderID_FK) VALUES (%s, %s)", (eventID, serviceProviderID))
        mysql.connection.commit()
        cursor.close()

        return jsonify({'message': 'Booking confirmed successfully'}), 200

    except Exception as e:
        print('Error confirming booking:', e)  # Add error logging
        return jsonify({'error': str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
