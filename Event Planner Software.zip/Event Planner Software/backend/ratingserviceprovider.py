from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_mysqldb import MySQL

app = Flask(__name__)
CORS(app)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'MySQL@12345'
app.config['MYSQL_DB'] = 'eventplannerdb'

mysql = MySQL(app)

# Route for fetching ratings and reviews for a specific service provider
@app.route('/ratingserviceprovider')
def get_ratings():
    try:
        # Retrieve service provider ID from request parameters
        service_provider_id = request.args.get('service_provider_id')

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT RatingID, RatingValue, ReviewDetails, Label FROM rating WHERE ServiceProviderID = %s", (service_provider_id,))
        ratings = cursor.fetchall()
        cursor.close()
        
        # Convert the data into a list of dictionaries
        ratings_list = []
        for row in ratings:
            rating_data = {
                "RatingID": row[0],
                "RatingValue": row[1],
                "ReviewDetails": row[2],
                "Label": row[3]
            }
            ratings_list.append(rating_data)
        
        return jsonify(ratings_list)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)