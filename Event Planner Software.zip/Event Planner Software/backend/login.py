from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_mysqldb import MySQL

app = Flask(__name__)
CORS(app)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'MySQL@12345'
app.config['MYSQL_DB'] = 'eventplannerdb'

mysql = MySQL(app)

@app.route('/login', methods=['POST'])
def login():
    try:
        data = request.json
        email = data.get('email')
        password = data.get('password')

        if not email or not password:
            return jsonify({'error': 'Please provide both email and password'}), 400
        
        cursor = mysql.connection.cursor()
        # Check user table for credentials
        cursor.execute("SELECT * FROM user WHERE Email = %s AND Password = %s", (email, password))
        user = cursor.fetchone()
        
        if user:
            return jsonify({'role': 'user'}), 200
        
        # Check service_provider table for credentials
        cursor.execute("SELECT * FROM service_provider WHERE Email = %s AND Password = %s", (email, password))
        service_provider = cursor.fetchone()
        
        if service_provider:
            return jsonify({'role': 'service_provider'}), 200
        
        return jsonify({'error': 'Invalid email or password'}), 401

    except Exception as e:
        print('Error logging in:', e)  # Print error message to console for debugging
        return jsonify({'error': 'An error occurred while logging in'}), 500

if __name__ == '__main__':
    app.run(debug=True)
