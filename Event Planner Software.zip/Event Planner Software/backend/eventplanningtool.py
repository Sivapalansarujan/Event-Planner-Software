from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_mysqldb import MySQL
from flask import request

app = Flask(__name__)
CORS(app)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'MySQL@12345'
app.config['MYSQL_DB'] = 'eventplannerdb'

mysql = MySQL(app)

@app.route('/getUserId', methods=['POST'])
def get_user_id():
    try:
        # Retrieve userEmail from request body
        request_data = request.json
        userEmail = request_data.get('userEmail')

        # Query database to fetch userId
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT UserID FROM user WHERE Email = %s", (userEmail,))
        userId = cursor.fetchone()[0]
        cursor.close()

        return jsonify({'userId': userId}), 200
    except Exception as e:
        print('Error fetching userId:', e)  # Add error logging
        return jsonify({'error': str(e)}), 500


@app.route('/events', methods=['POST'])
def create_event():
    try:
        # Retrieve event details from request body
        event_data = request.json
        eventName = event_data.get('eventName')
        eventType = event_data.get('eventType')
        eventDate = event_data.get('eventDate')
        eventLocation = event_data.get('eventLocation')
        eventBudget = event_data.get('eventBudget')
        userId = event_data.get('userId')  # Assuming userId is sent from frontend
        
        # Insert event details into the database
        cursor = mysql.connection.cursor()
        cursor.execute("""
            INSERT INTO event (EventName, EventType, EventDate, EventLocation, EventBudget, UserID)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (eventName, eventType, eventDate, eventLocation, eventBudget, userId))
        mysql.connection.commit()
        
        # Get the last inserted EventID
        event_id = cursor.lastrowid

        # Fetch selected service providers
        selected_service_providers = event_data.get('selectedCards', [])
        
        # Insert confirmed event details into confirmed_event table
        for provider_id in selected_service_providers:
            cursor.execute("""
                INSERT INTO confirmed_event (EventID_FK, ServiceProviderID_FK)
                VALUES (%s, %s)
            """, (event_id, provider_id))
            mysql.connection.commit()
        
        cursor.close()

        return jsonify({'message': 'Event created successfully', 'eventID': event_id}), 200
    except Exception as e:
        print('Error creating event:', e)  # Add error logging
        return jsonify({'error': str(e)}), 500

@app.route('/serviceProviders', methods=['GET'])
def get_best_service_providers():
    try:
        # Define the categories
        categories = [
            "Photography",
            "Videography",
            "Catering",
            "Beautician",
            "Decoration",
            "Venue",
            "Bakery",
            "Cakes",
            "Entertainment",
            "Transportation"
        ]

        cursor = mysql.connection.cursor()
        best_service_providers = []

        # Fetch the top-rated service provider for each category
        for category in categories:
            cursor.execute("""
                SELECT sp.ServiceProviderID, sp.ServiceProviderName, sp.Email AS ServiceProviderEmail, sc.CategoryName AS ServiceCategory, AVG(r.RatingValue) AS AverageRating
                FROM service_provider sp
                INNER JOIN rating r ON sp.ServiceProviderID = r.ServiceProviderID
                INNER JOIN service_category sc ON sp.CategoryID = sc.CategoryID
                WHERE sc.CategoryName = %s
                GROUP BY sp.ServiceProviderID
                ORDER BY AverageRating DESC
                LIMIT 1
            """, (category,))

            best_service_provider = cursor.fetchone()
            if best_service_provider:
                best_service_provider_dict = {
                    'ServiceProviderID': best_service_provider[0],
                    'ServiceProviderName': best_service_provider[1],
                    'ServiceProviderEmail': best_service_provider[2],
                    'ServiceCategory': best_service_provider[3],
                    'AverageRating': best_service_provider[4]
                }
                best_service_providers.append(best_service_provider_dict)

        cursor.close()

        return jsonify(best_service_providers), 200
    except Exception as e:
        print('Error fetching service providers:', e)  # Add error logging
        return jsonify({'error': str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True)
