from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_mysqldb import MySQL

app = Flask(__name__)
CORS(app)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'MySQL@12345'
app.config['MYSQL_DB'] = 'eventplannerdb'

mysql = MySQL(app)

@app.route('/resetpassword', methods=['POST'])
def resetpassword():
    try:
        data = request.json
        email = data.get('email')
        new_password = data.get('newPassword')

        cursor = mysql.connection.cursor()
        # Check if new password and confirm password match
        if new_password != data.get('confirmPassword'):
            return jsonify({'error': "New password and confirm password don't match"}), 400

        # Check if email exists in user table
        cursor.execute("SELECT * FROM user WHERE Email = %s", (email,))
        user = cursor.fetchone()

        if user:
            # Update password in user table
            cursor.execute("UPDATE user SET Password = %s WHERE Email = %s", (new_password, email))
            mysql.connection.commit()
            return jsonify({'message': 'Password changed successfully'}), 200

        # Check if email exists in service_provider table
        cursor.execute("SELECT * FROM service_provider WHERE Email = %s", (email,))
        service_provider = cursor.fetchone()

        if service_provider:
            # Update password in service_provider table
            cursor.execute("UPDATE service_provider SET Password = %s WHERE Email = %s", (new_password, email))
            mysql.connection.commit()
            return jsonify({'message': 'Password changed successfully'}), 200

        return jsonify({'error': 'Email not found'}), 404

    except Exception as e:
        print('Error resetting password:', e)
        return jsonify({'error': 'An error occurred while resetting password'}), 500

if __name__ == '__main__':
    app.run(debug=True)
