# userprofile.py backend

from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_mysqldb import MySQL

app = Flask(__name__)
CORS(app)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'MySQL@12345'
app.config['MYSQL_DB'] = 'eventplannerdb'

mysql = MySQL(app)

# Route for fetching user profile and booked service providers
@app.route('/user_profile', methods=['GET'])
def get_user_profile():
    try:
        # Retrieve user email from request parameters
        user_email = request.args.get('email')

        cursor = mysql.connection.cursor()

        # Fetch user profile data
        cursor.execute("SELECT UserID, UserName, Email, ContactNumber FROM user WHERE Email = %s", (user_email,))
        user_data = cursor.fetchone()

        # Fetch booked service providers data
        cursor.execute("""
            SELECT sp.ServiceProviderID, sp.ServiceProviderName, sp.Email, sp.AvailableService, sp.Amount
            FROM service_provider sp
            JOIN confirmed_event ce ON sp.ServiceProviderID = ce.ServiceProviderID_FK
            JOIN event e ON ce.EventID_FK = e.EventID
            JOIN user u ON e.UserID = u.UserID
            WHERE u.Email = %s
        """, (user_email,))
        service_providers = cursor.fetchall()

        cursor.close()

        # Convert the data into dictionaries
        user_profile = {
            "UserID": user_data[0],
            "UserName": user_data[1],
            "Email": user_data[2],
            "ContactNumber": user_data[3],
            "BookedServiceProviders": [
                {
                    "ServiceProviderID": row[0],
                    "ServiceProviderName": row[1],
                    "Email": row[2],
                    "AvailableService": row[3],
                    "Amount": row[4]
                }
                for row in service_providers
            ]
        }

        return jsonify(user_profile)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
