from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_mysqldb import MySQL

app = Flask(__name__)
CORS(app)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'MySQL@12345'
app.config['MYSQL_DB'] = 'eventplannerdb'

mysql = MySQL(app)

# Mapping of available services to CategoryID
service_category_mapping = {
    'photography': 3001,
    'videography': 3002,
    'catering': 3003,
    'beautician': 3004,
    'decoration': 3005,
    'venue': 3006,
    'bakeries_and_desserts': 3007,
    'cakes': 3008,
    'entertainment': 3009,
    'transportation': 3010
}

@app.route('/serviceprovider_signup', methods=['POST'])
def serviceprovider_signup():
    try:
        data = request.json
        name = data.get('name')
        email = data.get('email')
        password = data.get('password')
        available_service = data.get('availableService')
        location = data.get('location')
        amount = data.get('amount')
        
        # Check if required fields are missing
        if not name or not email or not password or not available_service:
            return jsonify({'error': 'Missing required fields'}), 400

        # Determine CategoryID based on the selected available service
        category_id = service_category_mapping.get(available_service)
        if category_id is None:
            return jsonify({'error': 'Invalid available service'}), 400

        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO service_provider (ServiceProviderName, Email, Password, AvailableService, Amount, Location, CategoryID) VALUES (%s, %s, %s, %s, %s, %s, %s)", (name, email, password, available_service, amount, location, category_id))
        mysql.connection.commit()
        cursor.close()

        return jsonify({'message': 'Service provider signed up successfully'}), 201

    except Exception as e:
        print('Error signing up service provider:', e)  # Print error message to console for debugging
        return jsonify({'error': 'An error occurred while signing up service provider'}), 500

if __name__ == '__main__':
    app.run(debug=True)
