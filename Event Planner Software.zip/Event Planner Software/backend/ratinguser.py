from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_mysqldb import MySQL
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
nltk.download('vader_lexicon')

app = Flask(__name__)
CORS(app)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'MySQL@12345'
app.config['MYSQL_DB'] = 'eventplannerdb'

mysql = MySQL(app)

# Initialize SentimentIntensityAnalyzer
sid = SentimentIntensityAnalyzer()

# Route for fetching ratings and reviews for a specific service provider
@app.route('/ratingserviceprovider')
def get_ratings():
    try:
        # Retrieve service provider ID from request parameters
        service_provider_id = request.args.get('service_provider_id')

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT RatingID, RatingValue, ReviewDetails, Label FROM rating WHERE ServiceProviderID = %s", (service_provider_id,))
        ratings = cursor.fetchall()
        cursor.close()
        
        # Convert the data into a list of dictionaries
        ratings_list = []
        for row in ratings:
            rating_data = {
                "RatingID": row[0],
                "RatingValue": row[1],
                "ReviewDetails": row[2],
                "Label": row[3]
            }
            ratings_list.append(rating_data)
        
        return jsonify(ratings_list)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/ratinguser', methods=['POST'])
def add_rating():
    try:
        # Get data from the request body
        data = request.json
        rating_value = data['RatingValue']
        review_details = data['ReviewDetails']
        service_provider_id = data['ServiceProviderID']  # Include ServiceProviderID

        # Get sentiment scores
        scores = sid.polarity_scores(review_details)

        # Determine sentiment based on compound score
        if scores['compound'] >= 0.05:
            sentiment = "positive"  # Positive
        elif scores['compound'] <= -0.05:
            sentiment = "negative"  # Negative
        else:
            sentiment = "neutral"  # Neutral
        
        label = sentiment

        # Insert new rating into the database with ServiceProviderID
        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO rating (RatingValue, ReviewDetails, ServiceProviderID, Label) VALUES (%s, %s, %s, %s)", (rating_value, review_details, service_provider_id, label))
        mysql.connection.commit()
        cursor.close()

        return jsonify({'message': 'Rating added successfully'}), 201
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)