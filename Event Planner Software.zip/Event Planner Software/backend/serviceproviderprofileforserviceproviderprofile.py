# serviceprovider.py backend

from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_mysqldb import MySQL

app = Flask(__name__)
CORS(app)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'MySQL@12345'
app.config['MYSQL_DB'] = 'eventplannerdb'

mysql = MySQL(app)

# Route for fetching service provider profile
@app.route('/service_provider', methods=['GET'])
def get_service_provider():
    try:
        # Retrieve service provider email from request parameters
        service_provider_email = request.args.get('email')

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT ServiceproviderID, ServiceproviderName, Email, Password, AvailableService, Amount FROM service_provider WHERE Email = %s", (service_provider_email,))
        service_provider = cursor.fetchone()
        cursor.close()

        if service_provider:
            # Convert the data into a dictionary
            service_provider_profile = {
                "ServiceproviderID": service_provider[0],
                "ServiceproviderName": service_provider[1],
                "Email": service_provider[2],
                "Password": service_provider[3],
                "AvailableService": service_provider[4],
                "Amount": service_provider[5]
            }

            return jsonify(service_provider_profile)
        else:
            return jsonify({'error': 'Service provider not found'}), 404
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
if __name__ == '__main__':
    app.run(debug=True)
